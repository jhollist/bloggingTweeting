#' Functions to reproduce work in Hollister, 2014
#' 
#' This package provides the ability to reproduce, along with the Rmd and 
#' makefile, the analysis and final, submitted document.  Functions for 
#' collecting the data, conducting the analysis, and laying out the figures
#' are included.  
#'   
#'             
#' @name hollisterOnline2014
NULL 
